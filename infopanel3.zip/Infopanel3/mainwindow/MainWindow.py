from PyQt5.QtWidgets import QMainWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setObjectName("mainwindow")
        self.resize(1600, 900)
        self.setStyleSheet("background-color: #0e2254")
