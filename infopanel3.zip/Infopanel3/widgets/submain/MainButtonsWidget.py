from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class MainButtonsWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.buttons_widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.buttons_widget.setObjectName("buttons_widget")
        self.newsButton = QtWidgets.QPushButton(self.buttons_widget)
        self.newsButton.setObjectName("newsButton")
        self.aboutButton = QtWidgets.QPushButton(self.buttons_widget)
        self.aboutButton.setObjectName("aboutButton")
        self.activityButton = QtWidgets.QPushButton(self.buttons_widget)
        self.activityButton.setObjectName("activityButton")
        self.raspButton = QtWidgets.QPushButton(self.buttons_widget)
        self.raspButton.setObjectName("raspButton")

        self.main_buttons = [self.newsButton, self.activityButton, self.aboutButton, self.raspButton]

        self.set_buttonswidget_geometry()
        self.set_buttonswidget_stylesheet()
        self.set_newsbutton()
        self.set_aboutbutton()
        self.set_activitybutton()
        self.set_raspbutton()
        self.set_buttons_effects()

        self.aboutButton.setStyleSheet("background-color: #bbbfc8;\n"
                                       "    color: #0e2254;\n"
                                       "    font: 20pt \"Yu Gothic UI\";\n"
                                       "    font-weight: light;\n"
                                       "    border-radius: 7px;\n")

    def set_buttonswidget_geometry(self):
        self.buttons_widget.setGeometry(QtCore.QRect(int(47 * 0.83), int(860 * 0.83), int(1810 * 0.83), int(200 * 0.83)))

    def set_buttonswidget_stylesheet(self):
        self.buttons_widget.setStyleSheet("QWidget#buttons_widget{\n"
                                          "    background-color: transparent;\n"
                                          "}")

    def set_newsbutton(self):
        self.newsButton.setGeometry(QtCore.QRect(int(10 * 0.83), int(60 * 0.83), int(320 * 0.83), int(70 * 0.83)))
        self.newsButton.setStyleSheet("QPushButton#newsButton{\n"
                                      "    background-color: #ebecf0;\n"
                                      "    color: #0e2254;\n"
                                      "    font: 20pt \"Yu Gothic UI\";\n"
                                      "    font-weight: light;\n"
                                      "    border-radius: 7px;\n"
                                      "}"
                                      "QPushButton#newsButton:hover{\n"
                                      "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                      "stop:1 #bbbfc8); "
                                      "}"
                                      "QPushButton#newsButton:pressed{\n"
                                      "    background-color: #bbbfc8;"
                                      "}"
                                      )
        self.newsButton.setText(QtCore.QCoreApplication.translate("mainwindow", "Новости"))

    def set_aboutbutton(self):
        self.aboutButton.setGeometry(QtCore.QRect(int(490 * 0.83), int(60 * 0.83), int(320 * 0.83), int(70 * 0.83)))
        self.aboutButton.setStyleSheet("QPushButton#aboutButton{\n"
                                       "    background-color: #ebecf0;\n"
                                       "    color: #0e2254;\n"
                                       "    font: 20pt \"Yu Gothic UI\";\n"
                                       "    font-weight: light;\n"
                                       "    border-radius: 7px;\n"
                                       "}"
                                       "QPushButton#aboutButton:hover{\n"
                                       "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                       "stop:1 #bbbfc8); "
                                       "}"
                                       "QPushButton#aboutButton:pressed{\n"
                                       "    background-color: #bbbfc8;"
                                       "}"
                                       )
        self.aboutButton.setText(QtCore.QCoreApplication.translate("mainwindow", "О лицее"))

    def set_activitybutton(self):
        self.activityButton.setGeometry(QtCore.QRect(int(970 * 0.83), int(60 * 0.83), int(320 * 0.83), int(70 * 0.83)))
        self.activityButton.setStyleSheet("QPushButton#activityButton{\n"
                                          "    background-color: #ebecf0;\n"
                                          "    color: #0e2254;\n"
                                          "    font: 20pt \"Yu Gothic UI\";\n"
                                          "    font-weight: light;\n"
                                          "    border-radius: 7px;\n"
                                          "}"
                                          "QPushButton#activityButton:hover{\n"
                                          "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                          "stop:1 #bbbfc8); "
                                          "}"
                                          "QPushButton#activityButton:pressed{\n"
                                          "    background-color: #bbbfc8;"
                                          "}"
                                          )
        self.activityButton.setText(QtCore.QCoreApplication.translate("mainwindow", "Разработчики"))

    def set_raspbutton(self):
        self.raspButton.setGeometry(QtCore.QRect(int(1450 * 0.83), int(60 * 0.83), int(320 * 0.83), int(70 * 0.83)))
        self.raspButton.setStyleSheet("QPushButton#raspButton{\n"
                                      "    background-color: #ebecf0;\n"
                                      "    color: #0e2254;\n"
                                      "    font: 20pt \"Yu Gothic UI\";\n"
                                      "    font-weight: light;\n"
                                      "    border-radius: 7px;\n"
                                      "}"
                                      "QPushButton#raspButton:hover{\n"
                                      "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                      "stop:1 #bbbfc8); "
                                      "}"
                                      "QPushButton#raspButton:pressed{\n"
                                      "    background-color: #bbbfc8;"
                                      "}"
                                      )
        self.raspButton.setText(QtCore.QCoreApplication.translate("mainwindow", "Расписание"))

    def set_buttons_effects(self):
        for i in self.main_buttons:
            i.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=35, offset=QtCore.QPoint(15, 15),
                                                                    color=QtGui.QColor('#1f1b3a')))
