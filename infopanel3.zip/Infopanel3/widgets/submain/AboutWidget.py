from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class AboutWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.about_widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.plaintext = QtWidgets.QPlainTextEdit(self.about_widget)
        self.lyceumPhoto_widget = QtWidgets.QWidget(self.about_widget)
        self.schedulePhoto_widget = QtWidgets.QWidget(self.about_widget)
        self.minobrrfPhoto_widget = QtWidgets.QWidget(self.about_widget)
        self.minobrnsoPhoto_widget = QtWidgets.QWidget(self.about_widget)
        self.ITSchoolPhoto_widget = QtWidgets.QWidget(self.about_widget)
        self.RANschoolPhoto_widget = QtWidgets.QWidget(self.about_widget)

        self.set_aboutwidget_geometry()
        self.set_aboutwidget_stylesheet()
        self.set_plaintext()
        self.set_lyceumphotowidget()
        self.set_schedulephotowidget()
        self.set_minobrrfphotowidget()
        self.set_minobrnsophotowidget()
        self.set_itschoolphotowidget()
        self.set_ranschoolphotowidget()

    def set_aboutwidget_geometry(self):
        self.about_widget.setGeometry(QtCore.QRect(int(50 * 0.83), int(200 * 0.83), int(1780 * 0.83), int(660 * 0.83)))

    def set_aboutwidget_stylesheet(self):
        self.about_widget.setStyleSheet("background-color: transparent;")

    def set_plaintext(self):
        self.plaintext.setGeometry(QtCore.QRect(int(770 * 0.83), int(5 * 0.83), int(690 * 0.83), int(270 * 0.83)))
        self.plaintext.setStyleSheet('background-color: transparent;'
                                     "font: 13pt \"Yu Gothic UI\";\n"
                                     "font-weight: light;\n"
                                     "color: #393939;\n"
                                     "border: 0;"
                                     )
        self.plaintext.setPlainText(
            QtCore.QCoreApplication.translate('mainwindow',
                                              'Муниципальное бюджетное общеобразовательное учреждение города '
                                              'Новосибирска '
                                              '"Инженерный лицей НГТУ" был открыт в августе 1996 года по инициативе '
                                              'НГТУ и '
                                              'Управления Образованием мэрии города Новосибирска. Учредитель '
                                              'образовательного '
                                              'учреждения: муниципальное образование, город Новосибирск.'))
        self.plaintext.setDisabled(True)

    def set_lyceumphotowidget(self):
        self.lyceumPhoto_widget.setGeometry(QtCore.QRect(int(250 * 0.83), int(20 * 0.83), int(422 * 0.83), int(413 * 0.83)))
        self.lyceumPhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/lyceum.png);"
                                              "border-radius: 13px;")
        self.lyceumPhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                      offset=QtCore.QPoint(15, 10),
                                                                                      color=QtGui.QColor('#1f1b3a')))

    def set_schedulephotowidget(self):
        self.schedulePhoto_widget.setGeometry(QtCore.QRect(int(775 * 0.83), int(290 * 0.83), int(540 * 0.83), int(110 * 0.83)))
        self.schedulePhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/schedule.png);"
                                                "border-radius: 13px;")
        self.schedulePhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                        offset=QtCore.QPoint(15, 10),
                                                                                        color=QtGui.QColor('#1f1b3a')))

    def set_minobrrfphotowidget(self):
        self.minobrrfPhoto_widget.setGeometry(QtCore.QRect(int(15 * 0.83), int(490 * 0.83), int(420 * 0.83), int(98 * 0.83)))
        self.minobrrfPhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/minobrrf.png);"
                                                "border-radius: 13px;")
        self.minobrrfPhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                        offset=QtCore.QPoint(15, 10),
                                                                                        color=QtGui.QColor('#1f1b3a')))

    def set_minobrnsophotowidget(self):
        self.minobrnsoPhoto_widget.setGeometry(QtCore.QRect(int(470 * 0.83), int(490 * 0.83), int(450 * 0.83), int(98 * 0.83)))
        self.minobrnsoPhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/minobrnso.png);"
                                                 "border-radius: 13px;")
        self.minobrnsoPhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                         offset=QtCore.QPoint(15, 10),
                                                                                         color=QtGui.QColor('#1f1b3a')))

    def set_itschoolphotowidget(self):
        self.ITSchoolPhoto_widget.setGeometry(QtCore.QRect(int(955 * 0.83), int(490 * 0.83), int(420 * 0.83), int(135 * 0.83)))
        self.ITSchoolPhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/ITSchool.png);"
                                                "border-radius: 13px;")
        self.ITSchoolPhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                        offset=QtCore.QPoint(int(15 * 0.83), int(10 * 0.83)),
                                                                                        color=QtGui.QColor('#1f1b3a')))

    def set_ranschoolphotowidget(self):
        self.RANschoolPhoto_widget.setGeometry(QtCore.QRect(int(1390 * 0.83), int(430 * 0.83), int(380 * 0.83), int(232 * 0.83)))
        self.RANschoolPhoto_widget.setStyleSheet("border-image: url(Infopanel3/data/photo/aboutwidget_photo/RANschool.png);"
                                                 "border-radius: 13px;")
        self.RANschoolPhoto_widget.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=40,
                                                                                         offset=QtCore.QPoint(int(15 * 0.83), int(10 * 0.83)),
                                                                                         color=QtGui.QColor('#1f1b3a')))
