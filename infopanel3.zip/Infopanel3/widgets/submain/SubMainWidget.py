from random import choice
from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.main.MainWidget import MainWidget


class SubMainWidget(MainWidget):
    def __init__(self):
        super().__init__()
        self.sub_mainwidget = QtWidgets.QWidget(self.mainwidget)
        self.sub_mainwidget.setObjectName("sub_mainwidget")
        self.logo_widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.logo_widget.setObjectName("logo_widget")
        self.name_label = QtWidgets.QLabel(self.sub_mainwidget)
        self.name_label.setObjectName("name_label")
        self.subtitle_header = QtWidgets.QLabel(self.sub_mainwidget)

        self.class_name_label = QtWidgets.QLabel(self.sub_mainwidget)

        self.set_submainwidget_geometry()
        self.set_submainwidget_stylesheet()
        self.set_logowidget()
        self.set_namelabel()
        self.set_subtitlelabel()
        self.set_class_name_label()

        self.setCentralWidget(self.mainwidget)

        self.subtitle_header.hide()
        self.class_name_label.hide()

    def set_submainwidget_geometry(self):
        self.sub_mainwidget.setGeometry(QtCore.QRect(int(20 * 0.83), int(20 * 0.83),
                                                     int(1880 * 0.83), int(1040 * 0.83)))

    def set_submainwidget_stylesheet(self):
        self.sub_mainwidget.setStyleSheet("QWidget#sub_mainwidget{\n"
                                          "    background-color: #ebecf0;\n"
                                          "    border-radius: 15px;\n"
                                          "}")

    def set_logowidget(self):
        self.logo_widget.setGeometry(QtCore.QRect(int(20 * 0.83), int(20 * 0.83), int(200 * 0.83), int(206 * 0.83)))
        self.logo_widget.setStyleSheet("QWidget#logo_widget{\n"
                                       "    background-color: transparent;\n"
                                       "    border-image: url(Infopanel3/data/photo/submainwidget_photo/Logo_L.png);\n"
                                       "}")

    def set_namelabel(self):
        self.name_label.setGeometry(QtCore.QRect(int(450 * 0.83), int(40 * 0.83), int(1100 * 0.83), int(61 * 0.83)))
        self.name_label.setStyleSheet("QLabel#name_label{\n"
                                      "    background-color: transparent;\n"
                                      "    font: 32pt \"Yu Gothic UI\";\n"
                                      "    font-weight: bold;\n"
                                      "    color: #393939;\n"
                                      "}")
        self.name_label.setText(QtCore.QCoreApplication.translate("mainwindow", "МБОУ \'\'Инженерный лицей НГТУ\'\'"))

    def set_subtitlelabel(self, text='Лицею 25 лет!'):
        self.subtitle_header.setGeometry(int(750 * 0.83), int(100 * 0.83), int(1100 * 0.83), int(90 * 0.83))
        self.subtitle_header.setStyleSheet("background-color: transparent;\n"
                                           "    font: 32pt \"Yu Gothic UI\";\n"
                                           "    font-weight: bold;\n"
                                           "    font-style: oblique;"
                                           "    color: red;\n")
        self.subtitle_header.setText(QtCore.QCoreApplication.translate("mainwindow", '{}'.format(text)))

    def set_class_name_label(self):
        self.class_name_label.setGeometry(50, 400, 120, 60)
        self.class_name_label.setStyleSheet("background-color: #ebecf0;\n"
                                            "    color: #0e2254;\n"
                                            "    font: 30pt \"Yu Gothic UI\";\n"
                                            "    font-weight: light;\n"
                                            "    border-radius: 7px;\n")
        colors = ['#18233F', '#051337', '#405EAA', '#5C72AA', '#907101', '#1E2F47', '#3A1E47', '#352252']
        self.class_name_label.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(15, 10),
                                                color=QtGui.QColor(choice(colors))))
