from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class CalendarWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.calendar_widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.calendar_widget.setObjectName("calendar_widget")
        self.day_label = QtWidgets.QLabel(self.calendar_widget)
        self.day_label.setObjectName("day_label")
        self.calendarLogo_widget = QtWidgets.QWidget(self.calendar_widget)
        self.calendarLogo_widget.setObjectName("calendarLogo_widget")
        self.date_label = QtWidgets.QLabel(self.calendarLogo_widget)
        self.date_label.setObjectName("date_label")
        self.time_label = QtWidgets.QLabel(self.calendar_widget)
        self.time_label.setObjectName("time_label")

        self.set_calendarwidget_geometry()
        self.set_calendarwidget_stylesheet()
        self.set_daylabel()
        self.set_calendarlogo()
        self.set_datelabel()
        self.set_timelabel()

    def set_calendarwidget_geometry(self):
        self.calendar_widget.setGeometry(QtCore.QRect(int(1645 * 0.83), int(10 * 0.83), int(300 * 0.83), int(200 * 0.83)))

    def set_calendarwidget_stylesheet(self):
        self.calendar_widget.setStyleSheet("background-color: transparent;")

    def set_daylabel(self):
        self.day_label.setGeometry(QtCore.QRect(int(90 * 0.83), int(130 * 0.83), int(90 * 0.83), int(60 * 0.83)))
        self.day_label.setStyleSheet("QLabel#day_label{\n"
                                     "    background-color: transparent;\n"
                                     "    font: 26pt \"Manrope\";\n"
                                     "    font-weight: medium;\n"
                                     "    color: #393939;\n"
                                     "}")

    def set_calendarlogo(self):
        self.calendarLogo_widget.setGeometry(QtCore.QRect(int(20 * 0.83), int(7 * 0.83), int(200 * 0.83), int(70 * 0.83)))
        self.calendarLogo_widget.setStyleSheet("QWidget#calendarLogo_widget{\n"
                                               "    background-color: #ebecf0;\n"
                                               "    border-radius: 13px;\n"
                                               "}")
        self.calendarLogo_widget.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=27, offset=QtCore.QPoint(0, 3),
                                                color=QtGui.QColor('#1f1b3a')))

    def set_datelabel(self):
        self.date_label.setGeometry(QtCore.QRect(int(10 * 0.83), int(16 * 0.83), int(200 * 0.83), int(40 * 0.83)))
        self.date_label.setStyleSheet("QLabel#date_label{\n"
                                      "    background-color: transparent;\n"
                                      "    font: 24pt \"Manrope\";\n"
                                      "    font-weight: medium;\n"
                                      "    color: #bd7800;\n"
                                      "}")

    def set_timelabel(self):
        self.time_label.setGeometry(QtCore.QRect(int(60 * 0.83), int(70 * 0.83), int(140 * 0.83), int(81 * 0.83)))
        self.time_label.setStyleSheet("QLabel#time_label{\n"
                                      "    background-color: transparent;\n"
                                      "    font: 26pt \"Manrope\";\n"
                                      "    font-weight: medium;\n"
                                      "    color: #393939;\n"
                                      "}")
