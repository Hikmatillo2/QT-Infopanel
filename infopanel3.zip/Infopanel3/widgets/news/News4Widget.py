from PyQt5 import QtCore, QtGui, QtWidgets
from Infopanel3.widgets.news.NewsMainWidget import NewsMainWidget


class News4Widget(NewsMainWidget):
    def __init__(self):
        super().__init__()
        self.news4_widget = QtWidgets.QWidget(self.news_mainwidget)
        self.news4_textedit = QtWidgets.QTextEdit(self.news4_widget)
        self.news4_photo = QtWidgets.QLabel(self.news4_widget)
        self.news4_Button = QtWidgets.QPushButton(self.news4_widget)
        self.news4_Button.setObjectName('news4_Button')

        self.set_news4widget_geometry()
        self.set_news4widget_stylesheet()
        self.set_news4textedit()
        self.set_news4photo()
        self.set_news4button()

    def set_news4widget_geometry(self):
        self.news4_widget.setGeometry(QtCore.QRect(int(565 * 0.83), int(360 * 0.83), int(380 * 0.83), int(270 * 0.83)))

    def set_news4widget_stylesheet(self):
        self.news4_widget.setStyleSheet("background-color: rgba(187, 191, 200, 90);"
                                        "border-radius: 13px")
        self.news4_widget.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=10, offset=QtCore.QPoint(0, 0),
                                                color=QtGui.QColor('#1f1b3a')))

    def set_news4textedit(self):
        self.news4_textedit.setGeometry(int(10 * 0.83), int(10 * 0.83), int(340 * 0.83), int(70 * 0.83))
        self.news4_textedit.setDisabled(True)

    def set_news4photo(self):
        self.news4_photo.setGeometry(int(80 * 0.83), int(80 * 0.83), int(200 * 0.83), int(110 * 0.83))
        photo = QtGui.QPixmap('Infopanel3/data/photo/newswidget_photo/news4.png')
        self.news4_photo.setPixmap(photo)

    def set_news4button(self):
        self.news4_Button.setGeometry(int(50 * 0.83), int(210 * 0.83), int(260 * 0.83), int(30 * 0.83))
        self.news4_Button.setStyleSheet("QPushButton#news4_Button{\n"
                                        "    background-color: #ebecf0;\n"
                                        "    color: #0e2254;\n"
                                        "    font: 14pt \"Yu Gothic UI\";\n"
                                        "    font-weight: light;\n"
                                        "    border-radius: 7px;\n"
                                        "}"
                                        "QPushButton#news4_Button:hover{\n"
                                        "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                        "stop:1 #bbbfc8); "
                                        "}")
        self.news4_Button.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.news4_Button.setText(QtCore.QCoreApplication.translate("MainWinow", "Читать"))
