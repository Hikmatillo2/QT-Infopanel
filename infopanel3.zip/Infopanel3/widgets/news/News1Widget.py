from PyQt5 import QtCore, QtGui, QtWidgets
from Infopanel3.widgets.news.NewsMainWidget import NewsMainWidget


class News1Widget(NewsMainWidget):
    def __init__(self):
        super().__init__()
        self.news1_widget = QtWidgets.QWidget(self.news_mainwidget)
        self.news1_textedit = QtWidgets.QTextEdit(self.news1_widget)
        self.news1_photo = QtWidgets.QLabel(self.news1_widget)
        self.news1_Button = QtWidgets.QPushButton(self.news1_widget)
        self.news1_Button.setObjectName('news1_Button')

        self.set_news1widget_geometry()
        self.set_news1widget_stylesheet()
        self.set_news1textedit()
        self.set_news1photo()
        self.set_news1button()

    def set_news1widget_geometry(self):
        self.news1_widget.setGeometry(QtCore.QRect(int(565 * 0.83), int(10 * 0.83), int(380 * 0.83), int(270 * 0.83)))

    def set_news1widget_stylesheet(self):
        self.news1_widget.setStyleSheet("background-color: rgba(187, 191, 200, 90);"
                                        "border-radius: 13px")
        self.news1_widget.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=10, offset=QtCore.QPoint(0, 0),
                                                color=QtGui.QColor('#1f1b3a')))

    def set_news1textedit(self):
        self.news1_textedit.setGeometry(int(10 * 0.83), int(10 * 0.83), int(340 * 0.83), int(70 * 0.83))
        self.news1_textedit.setDisabled(True)

    def set_news1photo(self):
        self.news1_photo.setGeometry(int(80 * 0.83), int(80 * 0.83), int(200 * 0.83), int(110 * 0.83))
        photo = QtGui.QPixmap('Infopanel3/data/photo/newswidget_photo/news1.png')
        self.news1_photo.setPixmap(photo)

    def set_news1button(self):
        self.news1_Button.setGeometry(int(50 * 0.83), int(210 * 0.83), int(260 * 0.83), int(30 * 0.83))
        self.news1_Button.setObjectName('news1_Button')
        self.news1_Button.setStyleSheet("QPushButton#news1_Button{\n"
                                        "    background-color: #ebecf0;\n"
                                        "    color: #0e2254;\n"
                                        "    font: 14pt \"Yu Gothic UI\";\n"
                                        "    font-weight: light;\n"
                                        "    border-radius: 7px;\n"
                                        "}"
                                        "QPushButton#news1_Button:hover{\n"
                                        "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                        "stop:1 #bbbfc8); "
                                        "}")
        self.news1_Button.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.news1_Button.setText(QtCore.QCoreApplication.translate("MainWinow", "Читать"))
