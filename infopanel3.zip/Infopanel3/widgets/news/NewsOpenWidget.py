from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class NewsOpenWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.NEWS_Widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.NEWS_heading = QtWidgets.QTextEdit(self.NEWS_Widget)
        self.NEWS_date = QtWidgets.QTextEdit(self.NEWS_Widget)
        self.NEWS_text = QtWidgets.QTextEdit(self.NEWS_Widget)
        self.NEWS_backButton = QtWidgets.QPushButton(self.NEWS_Widget)
        self.NEWS_backButton.setObjectName('NEWS_backButton')
        self.vsb_text = QtWidgets.QScrollBar()
        self.vsb_heading = QtWidgets.QScrollBar()

        self.set_newswidget_geometry()
        self.set_newswidget_stylesheet()
        self.set_newsheading()
        self.set_newsdate()
        self.set_newstext()
        self.set_newsbackbutton()
        self.set_vsbtext()
        self.set_vsbheading()
        self.NEWS_Widget.hide()

    def set_newswidget_geometry(self):
        self.NEWS_Widget.setGeometry(QtCore.QRect(0, int(210 * 0.83), int(1680 * 0.83), int(800 * 0.83)))

    def set_newswidget_stylesheet(self):
        self.NEWS_Widget.setStyleSheet("background-color: transparent;")

    def set_newsheading(self):
        self.NEWS_heading.setGeometry(int(220 * 0.83), int(10 * 0.83), int(1460 * 0.83), int(150 * 0.83))
        self.NEWS_heading.setStyleSheet("background-color: #ebecf0;\n"
                                        "    color: #0e2254;\n"
                                        "    font: 26pt \"Yu Gothic UI\";\n"
                                        "    font-weight: bold;\n"
                                        "    border-radius: 7px;\n")
        self.NEWS_heading.setReadOnly(True)

    def set_newsdate(self):
        self.NEWS_date.setGeometry(int(1170 * 0.83), int(710 * 0.83), int(480 * 0.83), int(50 * 0.83))
        self.NEWS_date.setStyleSheet("background-color: #ebecf0;\n"
                                     "    color: #0e2254;\n"
                                     "    font: 14pt \"Yu Gothic UI\";\n"
                                     "    font-weight: light;\n"
                                     "    border-radius: 7px;\n")
        self.NEWS_date.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(10, 10),
                                                color=QtGui.QColor('#1f1b3a')))
        self.NEWS_date.setDisabled(True)

    def set_newstext(self):
        self.NEWS_text.setGeometry(int(220 * 0.83), int(160 * 0.83), int(1460 * 0.83), int(540 * 0.83))
        self.NEWS_text.setStyleSheet("background-color: rgba(187, 191, 200, 90);\n"
                                     "    color: #393939;\n"
                                     "    font: 16pt \"Yu Gothic UI\";\n"
                                     "    font-weight: light;\n"
                                     "    border-radius: 7px;\n")
        self.NEWS_text.setReadOnly(True)

    def set_newsbackbutton(self):
        self.NEWS_backButton.setGeometry(int(220 * 0.83), int(710 * 0.83), int(140 * 0.83), int(50 * 0.83))
        self.NEWS_backButton.setStyleSheet("QPushButton#NEWS_backButton{\n"
                                           "    background-color: #ebecf0;\n"
                                           "    color: #0e2254;\n"
                                           "    font: 20pt \"Yu Gothic UI\";\n"
                                           "    font-weight: light;\n"
                                           "    border-radius: 7px;\n"
                                           "}"
                                           "QPushButton#NEWS_backButton:hover{\n"
                                           "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                           "stop:1 #bbbfc8); "
                                           "}")
        self.NEWS_backButton.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.NEWS_backButton.setText(QtCore.QCoreApplication.translate("mainwindow", "Назад"))

    def set_vsbtext(self):
        self.vsb_text.setStyleSheet('QScrollBar:vertical {'
                                    'background-color: #ebecf0;'
                                    ' }'
                                    'QScrollBar::handle:vertical {'
                                    'background-color: #0e2254;'
                                    'min-height: 10px;'
                                    '}')
        self.NEWS_text.setVerticalScrollBar(self.vsb_text)
        self.vsb_text.setEnabled(True)

    def set_vsbheading(self):
        self.vsb_heading.setStyleSheet('QScrollBar:vertical {'
                                       'background-color: #ebecf0;'
                                       ' }'
                                       'QScrollBar::handle:vertical {'
                                       'background-color: #0e2254;'
                                       'min-height: 10px;'
                                       '}')
        self.NEWS_heading.setVerticalScrollBar(self.vsb_heading)
        self.vsb_heading.setEnabled(True)
