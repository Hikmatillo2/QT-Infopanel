from PyQt5 import QtCore, QtWidgets
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class NewsMainWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.news_mainwidget = QtWidgets.QWidget(self.sub_mainwidget)

        self.set_newsmainwidget_geometry()
        self.set_newsmainwidget_stylesheet()
        self.news_mainwidget.hide()

    def set_newsmainwidget_geometry(self):
        self.news_mainwidget.setGeometry(QtCore.QRect(int(200 * 0.83), int(210 * 0.83), int(1580 * 0.83), int(660 * 0.83)))

    def set_newsmainwidget_stylesheet(self):
        self.news_mainwidget.setStyleSheet("background-color: transparent;")