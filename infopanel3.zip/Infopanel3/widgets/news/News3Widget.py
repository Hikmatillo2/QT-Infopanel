from PyQt5 import QtCore, QtGui, QtWidgets
from Infopanel3.widgets.news.NewsMainWidget import NewsMainWidget


class News3Widget(NewsMainWidget):
    def __init__(self):
        super().__init__()
        self.news3_widget = QtWidgets.QWidget(self.news_mainwidget)
        self.news3_textedit = QtWidgets.QTextEdit(self.news3_widget)
        self.news3_photo = QtWidgets.QLabel(self.news3_widget)
        self.news3_Button = QtWidgets.QPushButton(self.news3_widget)
        self.news3_Button.setObjectName('news3_Button')

        self.set_news3widget_geometry()
        self.set_news3widget_stylesheet()
        self.set_news3textedit()
        self.set_news3photo()
        self.set_news3button()

    def set_news3widget_geometry(self):
        self.news3_widget.setGeometry(QtCore.QRect(int(10 * 0.83), int(360 * 0.83), int(380 * 0.83), int(270 * 0.83)))

    def set_news3widget_stylesheet(self):
        self.news3_widget.setStyleSheet("background-color: rgba(187, 191, 200, 90);"
                                        "border-radius: 13px")
        self.news3_widget.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=10, offset=QtCore.QPoint(0, 0),
                                                color=QtGui.QColor('#1f1b3a')))

    def set_news3textedit(self):
        self.news3_textedit.setGeometry(int(10 * 0.83), int(10 * 0.83), int(340 * 0.83), int(70 * 0.83))
        self.news3_textedit.setDisabled(True)

    def set_news3photo(self):
        self.news3_photo.setGeometry(int(80 * 0.83), int(80 * 0.83), int(200 * 0.83), int(110 * 0.83))
        photo = QtGui.QPixmap('Infopanel3/data/photo/newswidget_photo/news3.png')
        self.news3_photo.setPixmap(photo)

    def set_news3button(self):
        self.news3_Button.setGeometry(int(50 * 0.83), int(210 * 0.83), int(260 * 0.83), int(30 * 0.83))
        self.news3_Button.setStyleSheet("QPushButton#news3_Button{\n"
                                        "    background-color: #ebecf0;\n"
                                        "    color: #0e2254;\n"
                                        "    font: 14pt \"Yu Gothic UI\";\n"
                                        "    font-weight: light;\n"
                                        "    border-radius: 7px;\n"
                                        "}"
                                        "QPushButton#news3_Button:hover{\n"
                                        "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                        "stop:1 #bbbfc8); "
                                        "}")
        self.news3_Button.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.news3_Button.setText(QtCore.QCoreApplication.translate("MainWinow", "Читать"))
