from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class RaspMainWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.RaspMainWidget = QtWidgets.QWidget(self.sub_mainwidget)
        self.previousWeekButton = QtWidgets.QPushButton(self.RaspMainWidget)
        self.currentWeekButton = QtWidgets.QPushButton(self.RaspMainWidget)
        self.futureWeekButton = QtWidgets.QPushButton(self.RaspMainWidget)
        self.li_buttons = [self.futureWeekButton, self.currentWeekButton, self.previousWeekButton]

        self.set_futureweekbutton()
        self.set_previousweekbutton()
        self.set_currentweekbutton()
        self.set_raspmainwidget_geometry()
        self.set_raspmainwidget_stylesheet()
        self.set_buttonsgraphic_effects()

        self.PREVIOUS_FLAG = False
        self.FUTURE_FLAG = False
        self.CURRENT_FLAG = False

        self.RaspMainWidget.hide()

    def set_raspmainwidget_geometry(self):
        self.RaspMainWidget.setGeometry(QtCore.QRect(int(50 * 0.83), int(200 * 0.83), int(1780 * 0.83), int(660 * 0.83)))

    def set_raspmainwidget_stylesheet(self):
        self.RaspMainWidget.setStyleSheet("background-color: transparent;")

    def set_previousweekbutton(self):
        self.previousWeekButton.setStyleSheet("background-color: #bbbfc8;\n"
                                              "    color: #0e2254;\n"
                                              "    font: 20pt \"Yu Gothic UI\";\n"
                                              "    font-weight: light;\n"
                                              "    border-radius: 7px;\n")
        self.previousWeekButton.setGeometry(int(145 * 0.83), int(130 * 0.83), int(400 * 0.83), int(400 * 0.83))
        self.previousWeekButton.setText(QtCore.QCoreApplication.translate("MainWinow", "Четная неделя"))

    def set_currentweekbutton(self):
        self.currentWeekButton.setStyleSheet("background-color: #bbbfc8;\n"
                                             "    color: #0e2254;\n"
                                             "    font: 20pt \"Yu Gothic UI\";\n"
                                             "    font-weight: light;\n"
                                             "    border-radius: 7px;\n")
        self.currentWeekButton.setGeometry(int(1235 * 0.83), int(130 * 0.83), int(400 * 0.83), int(400 * 0.83))
        self.currentWeekButton.setText(QtCore.QCoreApplication.translate("MainWinow", "Текущая неделя"))

    def set_futureweekbutton(self):
        self.futureWeekButton.setStyleSheet("background-color: #bbbfc8;\n"
                                            "    color: #0e2254;\n"
                                            "    font: 20pt \"Yu Gothic UI\";\n"
                                            "    font-weight: light;\n"
                                            "    border-radius: 7px;\n")
        self.futureWeekButton.setGeometry(int(690 * 0.83), int(130 * 0.83), int(400 * 0.83), int(400 * 0.83))
        self.futureWeekButton.setText(QtCore.QCoreApplication.translate("MainWinow", "Нечетная неделя"))

    def set_buttonsgraphic_effects(self):
        for i in self.li_buttons:
            i.setGraphicsEffect(
                QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(10, 10),
                                                    color=QtGui.QColor('#1f1b3a')))
