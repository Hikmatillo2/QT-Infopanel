from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget
from Infopanel3.widgets.rasp.schedule_day_widget.WidgetTools import WidgetTools


class RaspOpenWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.raspOpenWidget = QtWidgets.QTableWidget(self.sub_mainwidget)

        self.swipe = QtWidgets.QLabel(self.raspOpenWidget)
        gif = QtGui.QMovie('Infopanel3/data/photo/raspwidget_photo/swipe.gif')
        self.swipe.setMovie(gif)
        gif.setScaledSize(QtCore.QSize(200, 200))
        gif.start()

        self.swipe.setGeometry(1150, 160, 300, 300)

        WidgetTools.setup_table_widget(self.raspOpenWidget)
        self.raspOpenWidget.setColumnCount(3)
        self.raspOpenWidget.setRowCount(3)
        self.raspOpenWidget.setColumnWidth(1, 400)
        self.raspOpenWidget.setRowHeight(0, 300)
        self.raspOpenWidget.setRowHeight(2, 300)
        self.raspOpenWidget.setColumnWidth(0, 400)
        self.raspOpenWidget.setColumnWidth(2, 400)

        self.raspBackButton = QtWidgets.QPushButton(self.raspOpenWidget)
        self.raspBackButton.setObjectName('raspBackButton')
        self.days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота']
        self.raspOpenWidget.setStyleSheet('border: transparent;'
                                          'background-color: #ebecf0;')
        self.set_raspopenwidget_geometry()
        self.set_raspbackbutton()

        self.raspOpenWidget.hide()

    def set_raspopenwidget_geometry(self):
        self.raspOpenWidget.setGeometry(QtCore.QRect(int(250 * 0.83), int(150 * 0.83), int(1900 * 0.83), int(900 * 0.83)))

    def set_raspbackbutton(self):
        self.raspBackButton.setGeometry(int(570 * 0.83), int(770 * 0.83), int(200 * 0.83), int(60 * 0.83))
        self.raspBackButton.setStyleSheet("QPushButton#raspBackButton{\n"
                                          "    background-color: #ebecf0;\n"
                                          "    color: #0e2254;\n"
                                          "    font: 24pt \"Yu Gothic UI\";\n"
                                          "    font-weight: light;\n"
                                          "    border-radius: 7px;\n"
                                          "}"
                                          "QPushButton#raspBackButton:hover{\n"
                                          "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 #f8f8f8, "
                                          "stop:1 #bbbfc8); "
                                          "}")
        self.raspBackButton.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.raspBackButton.setText(QtCore.QCoreApplication.translate("mainwindow", "Назад"))
