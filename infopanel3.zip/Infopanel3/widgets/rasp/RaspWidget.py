from random import choice
from PyQt5 import QtWidgets, QtCore, QtGui
from Infopanel3.scripts.rasp_script import GetRasp
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class RaspWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.rasp_widget = QtWidgets.QWidget(self.sub_mainwidget)

        self.a1 = QtWidgets.QPushButton(self.rasp_widget)
        self.a2 = QtWidgets.QPushButton(self.rasp_widget)
        self.a3 = QtWidgets.QPushButton(self.rasp_widget)
        self.a4 = QtWidgets.QPushButton(self.rasp_widget)
        self.a5 = QtWidgets.QPushButton(self.rasp_widget)
        self.a6 = QtWidgets.QPushButton(self.rasp_widget)
        self.a7 = QtWidgets.QPushButton(self.rasp_widget)
        self.a8 = QtWidgets.QPushButton(self.rasp_widget)
        self.a9 = QtWidgets.QPushButton(self.rasp_widget)

        self.b1 = QtWidgets.QPushButton(self.rasp_widget)
        self.b2 = QtWidgets.QPushButton(self.rasp_widget)
        self.b3 = QtWidgets.QPushButton(self.rasp_widget)
        self.b4 = QtWidgets.QPushButton(self.rasp_widget)
        self.b5 = QtWidgets.QPushButton(self.rasp_widget)
        self.b6 = QtWidgets.QPushButton(self.rasp_widget)
        self.b7 = QtWidgets.QPushButton(self.rasp_widget)
        self.b8 = QtWidgets.QPushButton(self.rasp_widget)
        self.b9 = QtWidgets.QPushButton(self.rasp_widget)

        self.v1 = QtWidgets.QPushButton(self.rasp_widget)
        self.v2 = QtWidgets.QPushButton(self.rasp_widget)
        self.v3 = QtWidgets.QPushButton(self.rasp_widget)
        self.v5 = QtWidgets.QPushButton(self.rasp_widget)
        self.v6 = QtWidgets.QPushButton(self.rasp_widget)
        self.v7 = QtWidgets.QPushButton(self.rasp_widget)
        self.v8 = QtWidgets.QPushButton(self.rasp_widget)
        self.v9 = QtWidgets.QPushButton(self.rasp_widget)

        self.g8 = QtWidgets.QPushButton(self.rasp_widget)

        self.L10_1 = QtWidgets.QPushButton(self.rasp_widget)
        self.L10_2 = QtWidgets.QPushButton(self.rasp_widget)
        self.L10_3 = QtWidgets.QPushButton(self.rasp_widget)
        self.L10_4 = QtWidgets.QPushButton(self.rasp_widget)

        self.L11_1 = QtWidgets.QPushButton(self.rasp_widget)
        self.L11_2 = QtWidgets.QPushButton(self.rasp_widget)
        self.L11_3 = QtWidgets.QPushButton(self.rasp_widget)
        self.L11_4 = QtWidgets.QPushButton(self.rasp_widget)

        self.raspBackButton_classes = QtWidgets.QPushButton(self.rasp_widget)
        self.raspBackButton_classes.setObjectName('raspBackButton_classes')

        self.colors = ['#ff00ff', '#00ff00', '#808000', '#00ffff']

        self.rasp = GetRasp.getrasp()

        self.li_ALLbuttons = [self.a1, self.a2, self.a3, self.a4, self.a5, self.a6, self.a7, self.a8, self.a9, self.b1,
                              self.b2, self.b3, self.b4, self.b5, self.b6, self.b7, self.b8, self.b9, self.v1, self.v2,
                              self.v3, self.v5, self.v6, self.v7, self.v8, self.v9, self.g8, self.L10_1, self.L10_2,
                              self.L10_3, self.L10_4, self.L11_1, self.L11_2, self.L11_3, self.L11_4]

        self.li_FIRSTline = [self.a1, self.a2, self.a3, self.a4, self.a5, self.a6, self.a7, self.a8, self.a9,
                             self.L10_1, self.L11_1]
        self.li_SECONDline = [self.b1, self.b2, self.b3, self.b4, self.b5, self.b6, self.b7, self.b8, self.b9,
                              self.L10_2, self.L11_2]
        self.li_THIRDline = [self.v1, self.v2, self.v3, self.v5, self.v6, self.v7, self.v8, self.v9, self.L10_3,
                             self.L11_3]
        self.li_FOURTHline = [self.g8, self.L10_4, self.L11_4]

        self.set_raspwidget_geometry()
        self.set_raspwidget_stylesheet()
        self.set_buttons_stylesheet()
        self.set_buttons_geometry()
        self.set_rasp_buttons_effects()
        self.set_buttons_name()
        self.set_raspbackbutton_classes()

        self.rasp_widget.hide()

    def set_raspwidget_geometry(self):
        self.rasp_widget.setGeometry(QtCore.QRect(int(200 * 0.83), int(210 * 0.83), int(1580 * 0.83), int(660 * 0.83)))

    def set_raspwidget_stylesheet(self):
        self.rasp_widget.setStyleSheet("background-color: transparent;")

    def set_buttons_stylesheet(self):
        for i in self.li_ALLbuttons:
            i.setStyleSheet("background-color: #ebecf0;\n"
                            "    color: #0e2254;\n"
                            "    font: 20pt \"Yu Gothic UI\";\n"
                            "    font-weight: light;\n"
                            "    border-radius: 7px;\n")

    def set_buttons_geometry(self):
        x = int(5 * 0.83)
        y = int(150 * 0.83)
        for i in self.li_FIRSTline:
            i.setGeometry(x, y, int(100 * 0.83), int(60 * 0.83))
            x += int((10 + 90 + 40) * 0.83)
        x = int(5 * 0.83)
        for i in self.li_SECONDline:
            i.setGeometry(x, y + 65, int(100 * 0.83), int(60 * 0.83))
            x += int((10 + 90 + 40) * 0.83)
        x = int(5 * 0.83)
        for i in self.li_THIRDline[:3]:
            i.setGeometry(x, int((y + 180) * 0.83), int(100 * 0.83), int(60 * 0.83))
            x += int((10 + 90 + 40) * 0.83)
        for i in self.li_THIRDline[3:]:
            x += int((10 + 90 + 40) * 0.83)
            i.setGeometry(x, int((y + 180) * 0.83), int(100 * 0.83), int(60 * 0.83))
        x = 140
        self.L11_4.setGeometry(int((10 * x + 5) * 0.83), int((y + 260) * 0.83), int(100 * 0.83), int(60 * 0.83))
        self.L10_4.setGeometry(int((9 * x + 5) * 0.83), int((y + 260) * 0.83), int(100 * 0.83), int(60 * 0.83))
        self.g8.setGeometry(int((x * 7 + 5) * 0.83), int((y + 260) * 0.83), int(100 * 0.83), int(60 * 0.83))

    def set_rasp_buttons_effects(self):
        colors = ['#18233F', '#051337', '#405EAA', '#5C72AA', '#907101', '#1E2F47', '#3A1E47', '#352252']
        for i in self.li_ALLbuttons:
            i.setGraphicsEffect(QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(15, 10),
                                                                    color=QtGui.QColor(choice(colors))))

    def set_buttons_name(self):
        for i in range(len(self.li_FIRSTline) - 2):
            self.li_FIRSTline[i].setText(QtCore.QCoreApplication.translate("mainwindow", "{}А".format(i + 1)))
        for i in range(len(self.li_SECONDline) - 2):
            self.li_SECONDline[i].setText(QtCore.QCoreApplication.translate("mainwindow", "{}Б".format(i + 1)))
        for i in range(len(self.li_THIRDline[:3])):
            self.li_THIRDline[i].setText(QtCore.QCoreApplication.translate("mainwindow", "{}В".format(i + 1)))
        for i in range(len(self.li_THIRDline[3:]) - 2):
            self.li_THIRDline[i + 3].setText(QtCore.QCoreApplication.translate("mainwindow", "{}В".format(i + 5)))
        for i in range(len(self.li_FIRSTline[9:])):
            self.li_FIRSTline[i + 9].setText(QtCore.QCoreApplication.translate("mainwindow", "{}-1".format(i + 10)))
        for i in range(len(self.li_SECONDline[9:])):
            self.li_SECONDline[i + 9].setText(QtCore.QCoreApplication.translate("mainwindow", "{}-2".format(i + 10)))
        for i in range(len(self.li_THIRDline[8:])):
            self.li_THIRDline[i + 8].setText(QtCore.QCoreApplication.translate("mainwindow", "{}-3".format(i + 10)))
        self.g8.setText(QtCore.QCoreApplication.translate("mainwindow", "8Г"))
        self.L10_4.setText(QtCore.QCoreApplication.translate("mainwindow", "10-4"))
        self.L11_4.setText(QtCore.QCoreApplication.translate("mainwindow", "11-4"))

    def set_raspbackbutton_classes(self):
        self.raspBackButton_classes.setGeometry(int(40 * 0.83), int(500 * 0.83), int(200 * 0.83), int(60 * 0.83))
        self.raspBackButton_classes.setStyleSheet("QPushButton#raspBackButton_classes{\n"
                                                  "    background-color: #ebecf0;\n"
                                                  "    color: #0e2254;\n"
                                                  "    font: 24pt \"Yu Gothic UI\";\n"
                                                  "    font-weight: light;\n"
                                                  "    border-radius: 7px;\n"
                                                  "}"
                                                  "QPushButton#raspBackButton_classes:hover{\n"
                                                  "background-color: qlineargradient( x1:1 y1:0, x2:1 y2:1, stop:0 "
                                                  "#f8f8f8, "
                                                  "stop:1 #bbbfc8); "
                                                  "}")
        self.raspBackButton_classes.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(7, 7),
                                                color=QtGui.QColor('#1f1b3a')))
        self.raspBackButton_classes.setText(QtCore.QCoreApplication.translate("mainwindow", "Назад"))
