from PyQt5.QtCore import Qt
from PyQt5.QtGui import QBrush, QColor
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem

from Infopanel3.widgets.rasp.schedule_day_widget.WidgetTools import WidgetTools


class DayScheduleRowTime(QTableWidget):
    def __init__(self, width: int, height: int, begin: str, end: str):
        super().__init__(2, 1)
        WidgetTools.setup_table_widget(self)
        self.setFixedSize(width, height)
        self.setRowHeight(0, height // 2)
        self.setRowHeight(1, height // 2)
        self.setColumnWidth(0, width)
        begin_t = QTableWidgetItem(begin)
        begin_t.setTextAlignment(Qt.AlignHCenter + Qt.AlignBottom)
        begin_t.setForeground(QBrush(QColor(41, 108, 41)))
        self.setItem(0, 0, begin_t)
        end_t = QTableWidgetItem(end)
        end_t.setTextAlignment(Qt.AlignHCenter + Qt.AlignTop)
        end_t.setForeground(QBrush(QColor(41, 108, 41)))
        self.setItem(1, 0, end_t)