import PyQt5
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QAbstractItemView, QTableWidget
from Infopanel3.widgets.rasp.schedule_day_widget.DayScheduleDoubleRow import DayScheduleDoubleRow
from Infopanel3.widgets.rasp.schedule_day_widget.DayScheduleRow import DayScheduleRow


class DaySchedule(QTableWidget):
    def __init__(self, width: int, min_height: int, lessons: list):
        n_rows = len(lessons)
        super().__init__(n_rows, 1)
        self.verticalHeader().hide()
        self.horizontalHeader().hide()
        self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)

        vsb = PyQt5.QtWidgets.QScrollBar()
        vsb.setStyleSheet('QScrollBar:vertical {'
                                    'background-color: #ebecf0;'
                                    ' }'
                                    'QScrollBar::handle:vertical {'
                                    'background-color: #c9c9c9;'
                                    'min-height: 10px;'
                                    '}')
        self.setVerticalScrollBar(vsb)

        self.setFocusPolicy(Qt.NoFocus)
        self.setFixedWidth(width)
        self.setMinimumHeight(min_height)
        self.setColumnWidth(0, width)
        self.setShowGrid(True)
        self.__width = width
        for i in range(n_rows):
            if lessons[i]['is_double']:
                row = DayScheduleDoubleRow(width, 80, lessons[i])
            else:
                row = DayScheduleRow(width, 40, lessons[i])
            self.setRowHeight(i, row.height() + 1)
            self.setCellWidget(i, 0, row)
