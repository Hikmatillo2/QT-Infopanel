from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QBrush, QColor
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem

from Infopanel3.widgets.rasp.schedule_day_widget.DayScheduleRowTime import DayScheduleRowTime
from Infopanel3.widgets.rasp.schedule_day_widget.DayScheduleRowLesson import DayScheduleRowLesson
from Infopanel3.widgets.rasp.schedule_day_widget.WidgetTools import WidgetTools


class DayScheduleDoubleRow(QTableWidget):
    def __init__(self, width, height, data: dict):
        super().__init__(1, 3)
        WidgetTools.setup_table_widget(self)
        self.setFixedSize(width, height)
        self.setRowHeight(0, height)
        self.setColumnWidth(0, 20)
        self.setColumnWidth(1, 50)
        self.setColumnWidth(2, width - 70)
        line_n = QTableWidgetItem(data['index'])
        line_n.setTextAlignment(Qt.AlignCenter)
        line_n.setFont(QFont('Arial', 10, QFont.Bold))
        line_n.setForeground(QBrush(QColor(170, 170, 170)))
        self.setItem(0, 0, line_n)
        self.setCellWidget(0, 1, DayScheduleRowTime(50, height, data['time']['begin'], data['time']['end']))
        doubleRow = QTableWidget(2, 1)
        WidgetTools.setup_table_widget(doubleRow)
        doubleRow.setFixedSize(width - 70, height)
        doubleRow.setRowHeight(0, height // 2)
        doubleRow.setRowHeight(1, height // 2)
        doubleRow.setColumnWidth(0, width - 70)
        doubleRow.setCellWidget(0, 0, DayScheduleRowLesson(width - 70, height // 2, data['lesson']))
        doubleRow.setCellWidget(1, 0, DayScheduleRowLesson(width - 70, height // 2, data['second_lesson']))
        self.setCellWidget(0, 2, doubleRow)
