from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem
from Infopanel3.widgets.rasp.schedule_day_widget.WidgetTools import WidgetTools


class DayInfoSelector(QTableWidget):
    def __init__(self, width, height, text):
        super().__init__(1, 3)
        WidgetTools.setup_table_widget(self)
        self.setFixedSize(width, height)
        self.setRowHeight(0, height)
        self.setColumnWidth(0, height)
        self.setColumnWidth(1, width - 2 * height)
        self.setColumnWidth(2, height)
        self.setStyleSheet('background-color: qlineargradient(spread:pad,x1:0 y1:0, x2:0 y2:1,stop:0 #dbdbdb,stop:1 #bababa);'
                           'border-radius: 10px')

        Text = QTableWidgetItem("{}".format(text))
        Text.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        Text.setFont(QFont("Yu Gothic UI", 13, QFont.Bold))
        self.setItem(0, 1, Text)
