from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTableWidget, QAbstractItemView
from Infopanel3.widgets.rasp.schedule_day_widget.DaySchedule import DaySchedule
from Infopanel3.widgets.rasp.schedule_day_widget.DayInfoSelector import DayInfoSelector


class ScheduleContainer(QTableWidget):
    def __init__(self, ls, text):
        super().__init__(2, 1)
        self.verticalHeader().hide()
        self.horizontalHeader().hide()
        self.setColumnWidth(0, 500)
        self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setFocusPolicy(Qt.NoFocus)
        self.setShowGrid(False)
        schedule = DaySchedule(300, 250, ls.to_list())
        self.setCellWidget(1, 0, schedule)
        self.setRowHeight(3, schedule.height())

        selector = DayInfoSelector(330, 30, text)
        self.setCellWidget(0, 0, selector)
        self.setRowHeight(2, selector.height())
