from PyQt5.QtCore import Qt
from PyQt5.QtGui import QBrush, QColor, QFont
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem
from Infopanel3.widgets.rasp.schedule_day_widget.WidgetTools import WidgetTools


class DayScheduleRowLesson(QTableWidget):
    def __init__(self, width: int, height: int, data: dict):
        super().__init__(2, 1)
        WidgetTools.setup_table_widget(self)
        self.setFixedSize(width, height)
        self.setRowHeight(0, height // 2)
        self.setRowHeight(1, height // 2)
        self.setColumnWidth(0, width)

        lesson_n = QTableWidgetItem(data['lesson_name'])
        lesson_n.setTextAlignment(Qt.AlignLeft + Qt.AlignBottom)
        lesson_n.setForeground(QBrush(QColor(68, 62, 88)))
        lesson_n.setFont(QFont('Arial', 10, QFont.Bold))
        self.setItem(0, 0, lesson_n)

        teacher_cabinet_view = QTableWidget(1, 2)
        WidgetTools.setup_table_widget(teacher_cabinet_view)
        teacher_cabinet_view.setFixedSize(width, height // 2)

        teacher_t = QTableWidgetItem(data['teacher'])
        teacher_t.setTextAlignment(Qt.AlignLeft + Qt.AlignTop)
        teacher_t.setForeground(QBrush(QColor(68, 62, 88)))
        teacher_t.setFont(QFont('Arial', 10, italic=True))
        teacher_cabinet_view.setItem(0, 0, teacher_t)

        cabinet_t = QTableWidgetItem(f"({data['cabinet']})")
        cabinet_t.setTextAlignment(Qt.AlignLeft + Qt.AlignTop)
        cabinet_t.setFont(QFont('Arial', 10, QFont.Bold))
        teacher_cabinet_view.setItem(0, 1, cabinet_t)

        teacher_cabinet_view.resizeColumnsToContents()

        self.setCellWidget(1, 0, teacher_cabinet_view)