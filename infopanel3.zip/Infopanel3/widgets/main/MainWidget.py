from PyQt5 import QtWidgets
from Infopanel3.mainwindow.MainWindow import MainWindow


class MainWidget(MainWindow):
    def __init__(self):
        super().__init__()
        self.mainwidget = QtWidgets.QWidget(self)
        self.mainwidget.setObjectName("mainwidget")
