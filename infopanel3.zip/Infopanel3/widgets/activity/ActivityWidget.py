from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtGui import QFont
from Infopanel3.widgets.submain.SubMainWidget import SubMainWidget


class ActivityWidget(SubMainWidget):
    def __init__(self):
        super().__init__()
        self.activity_widget = QtWidgets.QWidget(self.sub_mainwidget)
        self.hikmatillo = QtWidgets.QLabel(self.activity_widget)
        self.header1 = QtWidgets.QLabel(self.activity_widget)
        self.name = QtWidgets.QLabel(self.activity_widget)
        self.thanksgiving = QtWidgets.QLabel(self.activity_widget)
        self.text = QtWidgets.QLabel(self.activity_widget)

        self.activity_widget.setStyleSheet('background-color: transparent')

        self.hikmatillo.setStyleSheet('border-radius: 20px;'
                                      'border-image: url(Infopanel3/data/photo/activitywidget_photo/hikmatillo.png);')
        self.hikmatillo.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(15, 10),
                                                color=QtGui.QColor('#1f1b3a')))
        self.hikmatillo.setGeometry(300, 80, 400, 400)

        self.header1.setText('Разработчики')
        self.header1.setFont(QFont('Yu Gothic UI', 30, QFont.Bold))
        self.header1.setStyleSheet('color: #0e2254')
        self.header1.setGeometry(600, 0, 900, 70)

        self.name.setText('@h1kmatillo')
        self.name.setStyleSheet('color: #0e2254')
        self.name.setFont(QFont('Yu Gothic UI', 25, QFont.Bold))
        self.name.setGeometry(300, 470, 240, 100)

        self.thanksgiving.setStyleSheet("background-color: #ebecf0;\n"
                                        "    color: #0e2254;\n"
                                        "    color: #393939;\n"
                                        "    font: 16pt \"Yu Gothic UI\";\n"
                                        "    font-weight: 500;\n"
                                        "    border-radius: 7px;\n")
        self.thanksgiving.setGeometry(820, 80, 420, 230)
        self.thanksgiving.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(15, 10),
                                                color=QtGui.QColor('#1f1b3a')))
        self.thanksgiving.setText('   Помощь в создании проекта:\n     @n3kochan\n     '
                                  '@denyux\n     @mr.breadnt\n   Моральная '
                                  'поддержка:\n     @redf_fox')

        self.text.setStyleSheet("background-color: #ebecf0;\n"
                                "    color: #0e2254;\n"
                                "    color: #393939;\n"
                                "    font: 16pt \"Yu Gothic UI\";\n"
                                "    font-weight: 500;\n"
                                "    border-radius: 7px;\n")
        self.text.setGeometry(820, 340, 420, 100)
        self.text.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect(blurRadius=30, offset=QtCore.QPoint(15, 10),
                                                color=QtGui.QColor('#1f1b3a')))
        self.text.setText(' Приложение создано учеником\n группы Л11-1 в 2021 году')

        self.activity_widget.setGeometry(
            QtCore.QRect(int(50 * 0.83), int(150 * 0.83), int(1780 * 0.83), int(660 * 0.83)))

        self.activity_widget.hide()
