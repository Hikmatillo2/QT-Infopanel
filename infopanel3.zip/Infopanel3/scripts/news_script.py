import os
import httplib2
import requests
from PIL import Image
from bs4 import BeautifulSoup


class GetArticle:
    def __init__(self, article=None):
        self.main_page = 'https://lyceum.nstu.ru/'
        self.page = requests.get('https://lyceum.nstu.ru/novosti/itemlist/category/1-news', verify=False)
        self.num_of_article = article

    def getting_links(self):
        content = BeautifulSoup(self.page.content, 'html.parser')
        links = content.select('a')
        li_links = []
        for i in links:
            if '<a href="/novosti/item/' in str(i):
                check = str(i).split()[1].split('"')[1]
                if check in li_links:
                    continue
                else:
                    li_links.append(check)
        li_links = li_links[:6]
        return str(li_links[self.num_of_article])

    def getting_images_links(self):
        li_images_links = []
        content = BeautifulSoup(self.page.content, 'html.parser')
        site = content.select('img')
        for i in site:
            if 'src="/media/k2' in str(i):
                one_time_variable = str(i).split('src')
                li_images_links.append([one_time_variable[0].split('"')[1], str(self.main_page +
                                                                                one_time_variable[1].split('"')[1])])
        return li_images_links

    def saving_images(self):
        li_images_links = self.getting_images_links()
        li_names = self.getting_names()
        cache = httplib2.Http(disable_ssl_certificate_validation=True)
        for i in li_names:
            with open('Infopanel3/data/photo/newswidget_photo/news{}.png'.format(li_names.index(i)), 'w') as image:
                image.truncate(0)
        for i in li_names:
            for j in li_images_links:
                if i == j[0]:
                    response, content = cache.request(j[1])
                    image = open('Infopanel3/data/photo/newswidget_photo/news{}.jpg'.format(li_names.index(i)), 'wb')
                    image.write(content)
                    image.close()
                    img = Image.open('Infopanel3/data/photo/newswidget_photo/news{}.jpg'.format(li_names.index(i)))
                    img.save('Infopanel3/data/photo/newswidget_photo/news{}.png'.format(li_names.index(i)))
                    os.remove(os.path.abspath('Infopanel3/data/photo/'
                                              'newswidget_photo/news{}.jpg'.format(li_names.index(i))))

    def getting_names(self):
        li_names_of_news = []
        content = BeautifulSoup(self.page.content, 'html.parser')
        names_of_news = content.select('a')
        for i in names_of_news:
            if '            </a>' in str(i):
                li_names_of_news.append(' '.join(str(i).split()[2:-1]))
        li_names_of_news = li_names_of_news[:6]
        return li_names_of_news

    def getting_date(self):
        li_dates_of_news = []
        content = BeautifulSoup(self.page.content, 'html.parser')
        dates_of_news = content.select('span')
        for i in dates_of_news:
            if 'catItemDateCreated' in str(i):
                li_dates_of_news.append(" ".join(str(i).split()[2:-1]))
        li_dates_of_news = li_dates_of_news[:6]
        return str(li_dates_of_news[self.num_of_article])

    def getting_text(self):
        li_text = []
        page_news = requests.get(self.main_page + self.getting_links(), verify=False)
        content = BeautifulSoup(page_news.content, 'html.parser')
        g = content.select('p')
        for i in g:
            ord_i = ord(str(i).strip()[3])
            if 1040 <= ord_i <= 1103 or 49 <= ord_i <= 57:
                li_text.append(str(i).split('p')[1])
        li_text = [i[1:-2] for i in li_text]
        return li_text

    def get_article(self):
        return [str(self.getting_names()[self.num_of_article]), self.getting_date(), self.getting_text()]
