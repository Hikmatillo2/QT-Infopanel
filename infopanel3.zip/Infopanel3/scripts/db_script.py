import sqlite3
from json import loads
import requests
from bs4 import BeautifulSoup


class WriteDB:
    def __init__(self):
        self.connection = sqlite3.connect('Infopanel3/data/database/Rasp.db')
        self.cursor = self.connection.cursor()
        self.json = ''

    def update_db(self):
        self.get_new_json()
        old_json1 = self.cursor.execute('''SELECT json from schedule WHERE id=0''').fetchone()
        old_json2 = self.cursor.execute('''SELECT json from schedule WHERE id=2''').fetchone()
        self.cursor.execute('''UPDATE schedule SET json = ? WHERE id=0''', (old_json2,))
        self.cursor.execute('''UPDATE schedule SET json = ? WHERE id=2''', (''.join(old_json1, )))
        self.connection.commit()
        self.connection.close()

    def get_new_json(self):
        url = 'https://lyceum.nstu.ru/rasp/schedule.html'
        content = requests.get(url, verify=False)
        content.encoding = 'utf-8'
        source = BeautifulSoup(content.text, "html.parser")
        schedule_js = requests.get('https://lyceum.nstu.ru/rasp/' + source.select("script")[0]['src'], verify=False)
        schedule_js.encoding = 'utf-8'
        schedule_js = BeautifulSoup(schedule_js.text, "html.parser")
        self.json = str(schedule_js)[133:-3]

    def get_next(self):
        return ''.join(self.cursor.execute('''SELECT json from schedule WHERE id=2''').fetchone())

    def get_prev(self):
        return ''.join(self.cursor.execute('''SELECT json from schedule WHERE id=0''').fetchone())

    def check(self):
        self.get_new_json()
        if int(*loads(self.json)['PERIODS'].keys()) % 2 == 0:
            return True
        return False
