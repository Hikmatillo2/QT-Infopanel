import requests


def return_to_app():
    content = requests.get('https://remoteecontrol.herokuapp.com/subtitle', stream=True)
    return content.text
