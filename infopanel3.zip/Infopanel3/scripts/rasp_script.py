from json import loads
import requests
from bs4 import BeautifulSoup


class GetRasp:
    @staticmethod
    def getrasp():
        url = 'https://lyceum.nstu.ru/rasp/schedule.html'
        content = requests.get(url, verify=False)
        content.encoding = 'utf-8'
        source = BeautifulSoup(content.text, "html.parser")
        schedule_js = requests.get('https://lyceum.nstu.ru/rasp/' + source.select("script")[0]['src'], verify=False)
        schedule_js.encoding = 'utf-8'
        data_py = loads(str(schedule_js.text)[133:-3])
        rasp_dict = {}
        for i in data_py["CLASSES"].keys():
            rasp_dict[data_py["CLASSES"][i]] = {'Понедельник': [], 'Вторник': [], 'Среда': [],
                                                'Четверг': [], 'Пятница': [], 'Суббота': []
                                                }
        print(rasp_dict)
        for group in data_py["CLASSES"].keys():
            class_ = data_py["CLASSES"][group]
            schedule = data_py['CLASS_SCHEDULE'][str(*data_py['PERIODS'].keys())][group]
            day = ''
            for i in schedule:
                if i[1] != '0':
                    num_of_lesson = i[1:]
                else:
                    num_of_lesson = i[-1]
                if data_py['DAY_NAMES'][int(i) // 100 - 1] != day:
                    day = data_py['DAY_NAMES'][int(i) // 100 - 1]
                if len(schedule[i]['s']) > 1:
                    subject, teacher, room, begin_time, end_time = '', '', '', '', ''
                    try:
                        subject = data_py['SUBJECTS'][schedule[i]['s'][0]]
                        teacher = data_py['TEACHERS'][schedule[i]['t'][0]]
                        room = data_py['ROOMS'][schedule[i]['r'][0]]
                        begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                        end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    except KeyError:
                        subject = 'Занятий нет'
                    rasp = [subject, teacher, room, begin_time, end_time]
                    try:
                        subject = data_py['SUBJECTS'][schedule[i]['s'][1]]
                        teacher = data_py['TEACHERS'][schedule[i]['t'][1]]
                        room = data_py['ROOMS'][schedule[i]['r'][1]]
                        begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                        end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    except KeyError:
                        subject = 'Занятий нет'
                    rasp_dict[class_][day].append([subject, teacher, room, begin_time, end_time] + rasp)
                else:
                    subject = data_py['SUBJECTS'][schedule[i]['s'][0]]
                    teacher = data_py['TEACHERS'][schedule[i]['t'][0]]
                    room = data_py['ROOMS'][schedule[i]['r'][0]]
                    begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                    end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    rasp_dict[class_][day].append([subject, teacher, room, begin_time, end_time])
        return rasp_dict

    @staticmethod
    def get_previousrasp(json):
        data_py = loads(json)
        rasp_dict = {}
        for i in data_py["CLASSES"].keys():
            rasp_dict[data_py["CLASSES"][i]] = {'Понедельник': [], 'Вторник': [], 'Среда': [],
                                                'Четверг': [], 'Пятница': [], 'Суббота': []
                                                }
        print(rasp_dict)
        for group in data_py["CLASSES"].keys():
            class_ = data_py["CLASSES"][group]
            schedule = data_py['CLASS_SCHEDULE'][str(*data_py['PERIODS'].keys())][group]
            day = ''
            for i in schedule:
                if i[1] != '0':
                    num_of_lesson = i[1:]
                else:
                    num_of_lesson = i[-1]
                if data_py['DAY_NAMES'][int(i) // 100 - 1] != day:
                    day = data_py['DAY_NAMES'][int(i) // 100 - 1]
                if len(schedule[i]['s']) > 1:
                    subject, teacher, room, begin_time, end_time = '', '', '', '', ''
                    try:
                        subject = data_py['SUBJECTS'][schedule[i]['s'][0]]
                        teacher = data_py['TEACHERS'][schedule[i]['t'][0]]
                        room = data_py['ROOMS'][schedule[i]['r'][0]]
                        begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                        end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    except KeyError:
                        subject = 'Занятий нет'
                    rasp = [subject, teacher, room, begin_time, end_time]
                    try:
                        subject = data_py['SUBJECTS'][schedule[i]['s'][1]]
                        teacher = data_py['TEACHERS'][schedule[i]['t'][1]]
                        room = data_py['ROOMS'][schedule[i]['r'][1]]
                        begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                        end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    except KeyError:
                        subject = 'Занятий нет'
                    rasp_dict[class_][day].append([subject, teacher, room, begin_time, end_time] + rasp)
                else:
                    subject = data_py['SUBJECTS'][schedule[i]['s'][0]]
                    teacher = data_py['TEACHERS'][schedule[i]['t'][0]]
                    room = data_py['ROOMS'][schedule[i]['r'][0]]
                    begin_time = data_py["LESSON_TIMES"][num_of_lesson][0]
                    end_time = data_py["LESSON_TIMES"][num_of_lesson][1]
                    rasp_dict[class_][day].append([subject, teacher, room, begin_time, end_time])
        print(rasp_dict)
        return rasp_dict
