# -*- coding: utf-8 -*-
import sys
import datetime
from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication
import urllib3
from Infopanel3.widgets.activity.ActivityWidget import ActivityWidget
from Infopanel3.widgets.submain.AboutWidget import AboutWidget
from Infopanel3.widgets.submain.CalendarWidget import CalendarWidget
from Infopanel3.widgets.submain.MainButtonsWidget import MainButtonsWidget
from Infopanel3.scripts.rasp_script import GetRasp
from Infopanel3.scripts.db_script import WriteDB
from Infopanel3.scripts.remotecontrol_script import return_to_app
from Infopanel3.scripts.news_script import GetArticle
from Infopanel3.widgets.news.News0Widget import News0Widget
from Infopanel3.widgets.news.News1Widget import News1Widget
from Infopanel3.widgets.news.News2Widget import News2Widget
from Infopanel3.widgets.news.News3Widget import News3Widget
from Infopanel3.widgets.news.News4Widget import News4Widget
from Infopanel3.widgets.news.News5Widget import News5Widget
from Infopanel3.widgets.news.NewsOpenWidget import NewsOpenWidget
from Infopanel3.widgets.rasp.RaspOpenWidget import RaspOpenWidget
from Infopanel3.widgets.rasp.RaspWidget import RaspWidget
from Infopanel3.widgets.rasp.RaspMainWidget import RaspMainWidget
from Infopanel3.widgets.rasp.schedule_day_widget.LessonArray import Lesson, LessonsArray
from Infopanel3.widgets.rasp.schedule_day_widget.ScheduleContainer import ScheduleContainer

# pyinstaller --onefile --noconsole infopanel3.py
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class Logic(CalendarWidget, News0Widget, News1Widget, News2Widget, News3Widget, News4Widget, News5Widget, AboutWidget,
            NewsOpenWidget, MainButtonsWidget, RaspWidget, RaspOpenWidget, RaspMainWidget, ActivityWidget):
    def __init__(self):
        super().__init__()
        self.digital_clock()
        self.update_data()
        self.NEWS_backButton.clicked.connect(self.backbutton_clicked)
        self.raspBackButton.clicked.connect(self.raspbackbutton_clicked)
        self.raspBackButton_classes.clicked.connect(self.raspbackbutton_classes_clicked)
        self.news_texts = [self.news0_textedit, self.news1_textedit, self.news2_textedit,
                           self.news3_textedit, self.news4_textedit, self.news5_textedit]
        self.main_buttons = [self.newsButton, self.activityButton, self.aboutButton, self.raspButton]
        self.news_buttons = [self.news0_Button, self.news1_Button, self.news2_Button,
                             self.news3_Button, self.news4_Button, self.news5_Button]
        for i in self.news_buttons:
            i.clicked.connect(self.news_buttonclicked)
        for i in self.main_buttons:
            i.clicked.connect(self.main_buttonclicked)
        for i in self.li_ALLbuttons:
            i.clicked.connect(self.raspbuttonsclicked)
        self.set_start_settings()
        for i in self.li_buttons:
            i.clicked.connect(self.week_buttons_clicked)
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.back_to_main)
        self.dayschedule = []
        self.timer_counter = 0

    def digital_clock(self):
        days = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС']
        time_live = datetime.datetime.today().strftime("%H:%M")
        date_live = datetime.datetime.today().strftime("%d.%m.%y")
        day_live = datetime.datetime.today().weekday()
        self.time_label.setText(QtCore.QCoreApplication.translate("mainwindow", time_live))
        self.date_label.setText(QtCore.QCoreApplication.translate("mainwindow", date_live))
        self.day_label.setText(QtCore.QCoreApplication.translate("mainwindow", days[day_live]))
        QtCore.QTimer.singleShot(200, self.digital_clock)

    def main_buttonclicked(self):
        sender = self.sender()
        self.set_raspbutton()
        self.set_aboutbutton()
        self.set_activitybutton()
        self.set_newsbutton()
        sender.setStyleSheet("background-color: #bbbfc8;\n"
                             "    color: #0e2254;\n"
                             "    font: 20pt \"Yu Gothic UI\";\n"
                             "    font-weight: light;\n"
                             "    border-radius: 7px;\n")

        if sender == self.aboutButton:
            if return_to_app():
                self.set_subtitlelabel(' ' + return_to_app())
            else:
                self.set_subtitlelabel()
            self.subtitle_header.show()
            self.raspButton.setEnabled(True)
            self.news_mainwidget.hide()
            self.raspOpenWidget.hide()
            self.rasp_widget.hide()
            self.RaspMainWidget.hide()
            self.class_name_label.hide()
            self.about_widget.show()
            self.activity_widget.hide()
        elif sender == self.newsButton:
            self.class_name_label.hide()
            self.raspButton.setEnabled(True)
            self.raspOpenWidget.hide()
            self.about_widget.hide()
            self.RaspMainWidget.hide()
            self.setting_news_names()
            self.rasp_widget.hide()
            self.news_mainwidget.show()
            self.activity_widget.hide()
            self.subtitle_header.hide()
            self.timer_script()
        elif sender == self.activityButton:
            self.subtitle_header.hide()
            self.class_name_label.hide()
            self.raspButton.setEnabled(True)
            self.raspOpenWidget.hide()
            self.about_widget.hide()
            self.RaspMainWidget.hide()
            self.news_mainwidget.hide()
            self.rasp_widget.hide()
            self.activity_widget.show()
            self.timer_script()
        elif sender == self.raspButton:
            self.subtitle_header.hide()
            self.activity_widget.hide()
            self.about_widget.hide()
            self.news_mainwidget.hide()
            self.set_rasp_buttons_effects()
            self.RaspMainWidget.show()
            self.timer_script()

    def news_buttonclicked(self):
        sender = self.sender()
        if sender == self.news0_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(0).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()
        elif sender == self.news1_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(1).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()
        elif sender == self.news2_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(2).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()
        elif sender == self.news3_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(3).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()
        elif sender == self.news4_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(4).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()
        elif sender == self.news5_Button:
            self.buttons_widget.hide()
            self.news_mainwidget.hide()
            text = GetArticle(5).get_article()
            self.NEWS_heading.setText(str(text[0]))
            self.NEWS_date.setText(str(text[1]))
            self.NEWS_text.setText(''.join(text[2]))
            self.NEWS_Widget.show()

    def setting_news_names(self):
        li_names = GetArticle(1).getting_names()
        for i in range(len(self.news_texts)):
            text = li_names[i]
            if len(' '.join(text.split())) > 40:
                self.news_texts[i].setText(str(text[:40]) + '...')
            else:
                self.news_texts[i].setText(text)

    def backbutton_clicked(self):
        self.NEWS_Widget.hide()
        self.news_mainwidget.show()
        self.buttons_widget.show()

    def week_buttons_clicked(self):
        self.raspButton.setDisabled(True)
        sender = self.sender()
        if sender == self.previousWeekButton:
            self.PREVIOUS_FLAG = True
        elif sender == self.futureWeekButton:
            self.FUTURE_FLAG = True
        else:
            self.CURRENT_FLAG = True
        self.RaspMainWidget.hide()
        self.buttons_widget.show()
        self.rasp_widget.show()

    def raspbuttonsclicked(self):
        self.class_name_label.show()
        self.rasp_widget.hide()
        self.buttons_widget.hide()
        sender = self.sender()
        self.dayschedule.clear()
        group = sender.text()
        if len(group) > 2:
            self.class_name_label.setText(QtCore.QCoreApplication.translate("mainwindow", ' ' + group))
        else:
            self.class_name_label.setText(QtCore.QCoreApplication.translate("mainwindow", '  ' + group))
        if '-' in group:
            pass
        else:
            group = group[0] + group[1].lower()
        if self.FUTURE_FLAG:
            rasp = GetRasp.get_previousrasp(WriteDB().get_next())[group]
        elif self.PREVIOUS_FLAG:
            rasp = GetRasp.get_previousrasp(WriteDB().get_prev())[group]
        else:
            rasp = GetRasp.getrasp()[group]
        co = 0
        for i in rasp.keys():
            ls = LessonsArray()
            for j in rasp[i]:
                if len(j) < 6:
                    ls.add_lesson(Lesson(j[0], j[1], j[2], j[3], j[4]))
                else:
                    ls.add_lesson(Lesson(j[0], j[1], j[2], j[3], j[4], True, j[5], j[6], j[7]))
            self.dayschedule.append(ScheduleContainer(ls, self.days[co]))
            co += 1
        self.raspOpenWidget.setCellWidget(0, 0, self.dayschedule[0])
        self.raspOpenWidget.setCellWidget(0, 1, self.dayschedule[1])
        self.raspOpenWidget.setCellWidget(0, 2, self.dayschedule[2])
        self.raspOpenWidget.setCellWidget(2, 0, self.dayschedule[3])
        self.raspOpenWidget.setCellWidget(2, 1, self.dayschedule[4])
        self.raspOpenWidget.setCellWidget(2, 2, self.dayschedule[5])

        self.raspOpenWidget.show()

    def raspbackbutton_clicked(self):
        self.raspOpenWidget.hide()
        self.buttons_widget.show()
        self.rasp_widget.show()
        self.class_name_label.hide()

    def raspbackbutton_classes_clicked(self):
        self.rasp_widget.hide()
        self.RaspMainWidget.show()
        self.buttons_widget.show()
        self.raspButton.setEnabled(True)
        self.class_name_label.hide()

        self.PREVIOUS_FLAG = False
        self.FUTURE_FLAG = False
        self.CURRENT_FLAG = False

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

    def set_start_settings(self):
        for i in self.news_texts:
            i.setStyleSheet('background-color: transparent;'
                            "font: 11pt \"Yu Gothic UI\";\n"
                            "font-weight: light;\n"
                            "color: #393939;\n"
                            "border: 0;")
        self.aboutButton.setStyleSheet("background-color: #bbbfc8;\n"
                                       "    color: #0e2254;\n"
                                       "    font: 24pt \"Yu Gothic UI\";\n"
                                       "    font-weight: light;\n"
                                       "    border-radius: 7px;\n")
        self.subtitle_header.show()

    def update_data(self):
        GetArticle().saving_images()
        QtCore.QTimer.singleShot(18 * 10 ** 6, self.update_data)

    def back_to_main(self):
        self.subtitle_header.show()
        self.backbutton_clicked()
        self.news_mainwidget.hide()
        self.raspOpenWidget.hide()
        self.rasp_widget.hide()
        self.RaspMainWidget.hide()
        self.class_name_label.hide()
        self.about_widget.show()
        self.activity_widget.hide()
        self.buttons_widget.show()
        self.aboutButton.setStyleSheet("background-color: #bbbfc8;\n"
                                       "    color: #0e2254;\n"
                                       "    font: 20pt \"Yu Gothic UI\";\n"
                                       "    font-weight: light;\n"
                                       "    border-radius: 7px;\n")
        self.aboutButton.click()

    def timer_script(self):
        '''QtCore.QTimer.singleShot(10000, self.back_to_main)'''
        self.timer.stop()
        QtCore.QTimer.start(self.timer, 180000)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Logic()
    ex.show()
    sys.exit(app.exec_())
